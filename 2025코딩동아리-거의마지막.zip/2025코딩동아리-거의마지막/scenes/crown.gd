extends Area2D

@export var teleport_position: Vector2 = Vector2(6550, 10)

func _ready():
	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		print("텔레포트 실행")
		body.global_position = teleport_position

		# 전역 좌표 즉시 갱신
		Global.player_x = teleport_position.x
		Global.player_y = teleport_position.y
